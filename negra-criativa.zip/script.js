const services=["Análise de Perfil","Social Media","Artes para redes sociais","Landing Page","Identidade Visual","Tráfego pago"];
document.getElementById("svc").innerHTML=services.map(s=>`<div class="svc">${s}</div>`).join("");
const pk={insta:[["Básico",950,["Análise de perfil","Pesquisa de mercado","Desenvolvimento de conteúdo (tema + legenda)","10 posts mensais"]],
["Padrão",2100,["Análise de perfil","Pesquisa de mercado","Alinhamento visual","20 posts mensais","Alinhamento de estratégias digitais","Criação de Destaques"]],
["Padrão II",3100,["Análise de perfil","Pesquisa de mercado","Alinhamento visual","30 posts mensais","Alinhamento de estratégias digitais","Criação de Destaques"]],
["Premium",5000,["Análise de perfil","Pesquisa de mercado","Alinhamento visual","Curadoria de conteúdo","Consultoria","30 posts mensais","Gestão de Tráfego Pago","Programação dos posts"]]],
lp:[["Básico",3500,["Design personalizado","Copywriting persuasivo","Formulário de captura de leads","Imagens e mídia de qualidade","SEO básico"]],
["Padrão",5500,["Tudo do Básico","Análise e rastreamento","Suporte e manutenção 3 meses","Rodapé completo"]],
["Premium",9100,["Tudo do Padrão","Conteúdo dinâmico","Automação de marketing","Suporte e manutenção 6 meses","Consultoria"]]]};
const box=document.getElementById("pk");
function show(k){box.innerHTML=pk[k].map(([n,p,l])=>`<article class="card"><h3>${n}</h3><ul>${l.map(i=>`<li>${i}</li>`).join("")}</ul><div class="price"><small>R$</small> ${p.toLocaleString("pt-BR")}</div></article>`).join("")}
document.querySelectorAll(".tabs button").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tabs button").forEach(x=>x.classList.remove("on"));b.classList.add("on");show(b.dataset.t)});
show("insta");
document.getElementById("wa").href="https://wa.me/55SEUNUMERO?text="+encodeURIComponent("Olá Raquel! Quero saber mais sobre os pacotes da Negra Criativa.");
